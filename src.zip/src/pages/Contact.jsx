import { useState } from "react";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../firebase/firebaseConfig";

export default function Contact() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const [submitting, setSubmitting] = useState(false);
  const [msg, setMsg] = useState({ type: "", text: "" });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMsg({ type: "", text: "" });

    setSubmitting(true);
    try {
      // ✅ Save contact inquiry into Firestore (same collection used by admin inquiries)
      await addDoc(collection(db, "inquiries"), {
        type: "contact", // 👈 so admin can identify it's from Contact page
        status: "new",
        name: form.name,
        email: form.email,
        phone: form.phone,
        message: form.message,
        createdAt: serverTimestamp(),
      });

      setMsg({
        type: "success",
        text: "Thanks for contacting us! Our team will reach out shortly.",
      });

      setForm({ name: "", email: "", phone: "", message: "" });
    } catch (err) {
      console.error(err);
      setMsg({
        type: "danger",
        text: "Something went wrong. Please try again.",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-light">
      {/* Header */}
      <div
        className="py-5"
        style={{ background: "linear-gradient(90deg, #111, #333)" }}
      >
        <div className="container text-white">
          <h1 className="fw-bold mb-2">Contact LuxeDrive</h1>
          <p className="mb-0 text-white-50">
            Have questions about a car or want to schedule a visit? We’re here to help.
          </p>
        </div>
      </div>

      <div className="container py-5">
        <div className="row g-4">
          {/* Contact Form */}
          <div className="col-lg-7">
            <div className="card shadow-sm border-0">
              <div className="card-body p-4">
                <h4 className="fw-bold mb-1">Send us a message</h4>
                <p className="text-muted mb-4">
                  Our sales team usually responds within 24 hours.
                </p>

                {msg.text && (
                  <div className={`alert alert-${msg.type} py-2`} role="alert">
                    {msg.text}
                  </div>
                )}

                <form onSubmit={handleSubmit}>
                  <div className="row g-3">
                    <div className="col-md-6">
                      <label className="form-label">Full Name</label>
                      <input
                        className="form-control"
                        placeholder="Enter your full name"
                        required
                        disabled={submitting}
                        value={form.name}
                        onChange={(e) =>
                          setForm({ ...form, name: e.target.value })
                        }
                      />
                    </div>

                    <div className="col-md-6">
                      <label className="form-label">Email</label>
                      <input
                        type="email"
                        className="form-control"
                        placeholder="Enter proper email address"
                        required
                        disabled={submitting}
                        value={form.email}
                        onChange={(e) =>
                          setForm({ ...form, email: e.target.value })
                        }
                      />
                    </div>

                    <div className="col-md-6">
                      <label className="form-label">Phone</label>
                      <input
                        className="form-control"
                        placeholder="Enter your phone number"
                        required
                        disabled={submitting}
                        value={form.phone}
                        onChange={(e) =>
                          setForm({ ...form, phone: e.target.value })
                        }
                      />
                    </div>

                    <div className="col-md-6">
                      <label className="form-label">Purpose</label>
                      <input
                        className="form-control"
                        value="General inquiry / visit"
                        disabled
                      />
                    </div>

                    <div className="col-12">
                      <label className="form-label">Message</label>
                      <textarea
                        className="form-control"
                        rows="5"
                        placeholder="Tell us which car you're interested in or when you'd like to visit..."
                        required
                        disabled={submitting}
                        value={form.message}
                        onChange={(e) =>
                          setForm({ ...form, message: e.target.value })
                        }
                      />
                    </div>

                    <div className="col-12">
                      <button
                        className="btn btn-dark w-100"
                        disabled={submitting}
                      >
                        {submitting ? "Submitting..." : "Submit Message"}
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>

          {/* Info + Trust Section */}
          <div className="col-lg-5">
            {/* Dealership Info */}
            <div className="card shadow-sm border-0 mb-4">
              <div className="card-body p-4">
                <h5 className="fw-bold mb-3">Dealership Information</h5>

                <div className="mb-3">
                  <div className="text-muted small">Location</div>
                  <div className="fw-semibold">
                    LuxeDrive Premium Cars, City Center
                  </div>
                </div>

                <div className="mb-3">
                  <div className="text-muted small">Phone</div>
                  <div className="fw-semibold">+91 90000 00000</div>
                </div>

                <div className="mb-3">
                  <div className="text-muted small">Email</div>
                  <div className="fw-semibold">sales@luxedrive.com</div>
                </div>

                <div>
                  <div className="text-muted small">Business Hours</div>
                  <div className="fw-semibold">
                    Mon – Sat: 10:00 AM – 7:00 PM
                  </div>
                </div>
              </div>
            </div>

            {/* Why Choose Us */}
            <div className="card shadow-sm border-0">
              <div className="card-body p-4">
                <h5 className="fw-bold mb-3">Why Choose LuxeDrive?</h5>

                <ul className="list-unstyled mb-0">
                  <li className="mb-2">✔ Handpicked premium cars only</li>
                  <li className="mb-2">✔ Transparent pricing & real stock</li>
                  <li className="mb-2">✔ Easy inquiry & test drive booking</li>
                  <li className="mb-2">✔ Trusted by luxury car buyers</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
